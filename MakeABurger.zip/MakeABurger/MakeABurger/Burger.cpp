#include <iostream>
#include "Cat.h"
using namespace std;

string bread1;
string meat1;
string vegs[4];
string sauces[4];

void Cat::bread() {
    cout << "Choose bread: 1.Plain (default option) 2.Sesame 3.Potato" << endl;
    int bread;
    cin >> bread;

    switch (bread)
    {
    case 1: bread1 = "Plain";
        break;
    case 2: bread1 = "Sesame";
        break;
    case 3: bread1 = "Potato";
        break;
    default: bread1 = "Plain";
    }
}

void Cat::meat() {
    cout << "Choose meat: 1. Chicken 2. Beef (default option) 3. Fish 4. Vegetarian" << endl;
    int meat;
    cin >> meat;
    switch (meat)
    {
    case 1: meat1 = "Chicken";
        break;
    case 2: meat1 = "Beef";
        break;
    case 3: meat1 = "Fish";
        break;
    case 4: meat1 = "Vegetarian";
        break;
    default: meat1 = "Beef";
    }
}

void Cat::vegetables() {
    cout << "Pick up to 4 among the following vegetables: 1. Tomato 2. Lettuce 3.Pickles 4.Onions 5.Finished choosing vegetables" << endl;
    for (int i = 0; i < 4; i++) {
        int vegts;
        cin >> vegts;
        if (vegts > 4) {
            break;
        }
        switch (vegts)
        {
        case 1: vegs[i] = "Tomato";
            break;
        case 2: vegs[i] = "Lettuce";
            break;
        case 3: vegs[i] = "Pickles";
            break;
        case 4: vegs[i] = "Onions";
            break;
        default: break;
        }
    }

}

void Cat::sauce() {
    cout << "Pick up to 4 among the following condiments: 1. Ketchup 2. Mustard 3.Mayo 4.Relish 5.Finished choosing condiments" << endl;
    for (int k = 0; k < 4; k++) {
        int sauce;
        cin >> sauce;
        if (sauce > 4) {
            break;
        }
        switch (sauce)
        {
        case 1: sauces[k] = "Ketchup";
            break;
        case 2: sauces[k] = "Mustard";
            break;
        case 3: sauces[k] = "Mayo";
            break;
        case 4: sauces[k] = "Relish";
            break;
        default: break;
        }
    }
}

void Cat::complete() {
    cout << endl << endl << endl;
    cout << "Here is your sandwhich" << endl;
    cout << "----------------------" << endl;
    cout << bread1 << endl;
    cout << meat1 << endl;
    for (int i = 0; i < 4; i++) {
        if (vegs[i] != "") {
            cout << vegs[i] << endl;
        }
    }
    for (int i = 0; i < 4; i++) {
        if (sauces[i] != "") {
            cout << sauces[i] << endl;
        }
    }
    cout << bread1 << endl;
    cout << "----------------------" << endl;
}