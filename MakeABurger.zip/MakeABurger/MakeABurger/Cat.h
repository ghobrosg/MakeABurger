#ifndef CAT_H_
#define CAT_H_

class Cat {
public:
    void bread();
    void meat();
    void vegetables();
    void sauce();
    void complete();
};
#endif